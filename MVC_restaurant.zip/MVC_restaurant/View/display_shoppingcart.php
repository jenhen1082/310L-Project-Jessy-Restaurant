
<?php
    require_once("../Controller/productitem_controller.php");

    $productID = "";

    if(isset($_POST["ProductID"]))
    {
        $productID = $_POST["productID"];
        $productID = getProduct($productID);
    }


?>
<html>
<style>
      body {
        background-color: #FFF5DC;
    }
    h1{
        text-align:center;
        text-decoration-line: underline overline;
    }
    table {
        border-spacing: 5px;
    }
    table, th,td {
        border:1px solid black;
        border-collapse: collapse;
    }
    th, td 
    {
        padding: 15px;
        text-align: center;
    }
    th{
        background-color: #FCBA12;
    }
    tr
    {
         background-color: #FED777;
    }
</style>
<table> 
    <h1>Shopping Cart</h1>
        <tr>
            <th>Item</th>
            <th>description</th>
            <th>Quantity</th>
            <th></th>
            <th></th>
           
        </tr>
    
    <?php
    
    while($product = mysqli_fetch_array($cartresult)):; 
    ?>
       <tr>
           <td><?php echo $product["ProductName"]; ?></td>
           <td><?php echo $product["ProductDescription"]; ?><br><?php echo "$".$product["ProductCost"]; ?>
            <br> <?php echo $product["Request"] ;?></td> 
        
           <td><?php echo $product["QuantityInCart"]; ?></td>
           <td>
                 <form method="POST">
                    <input style="background-color:#FED777; " type="submit" value="Edit Item" name="edit"/>
                    <input style="background-color:#FED777; " type= "hidden" value="<?php echo $product["ProductID"]; ?>" name ="productID" />
                    
                </form>
            </td>
            <td>
                <form method="POST">
                    <input style="background-color:#FED777; " type="submit" value="Delete Item" name="delete"/>
                    <input style="background-color:#FED777; " type= "hidden" value="<?php echo $product["ProductID"]; ?>" name ="productID" />
                </form>
            </td>
           
       </tr>
       <?php endwhile;?>
</table>

<table>
    <tr>
         <td><strong>Subtotal:</strong></td>
            <td><?php echo number_format($subtotal, 2); ?></td>    
    </tr>
    <tr>
         <td><strong>tax:(5%)</strong></td>
            <td><?php echo number_format($tax, 2); ?></td> 
    </tr>
    <tr>
         <td><strong>Shipping&Handling(10%):</strong></td>
            <td><?php echo number_format($shippingAndHandling, 2); ?></td>
    </tr>
    <tr>
        <td><strong>total:</strong></td>
           <td><?php echo number_format($productTotal, 2); ?></td>
    </tr>
</table>
<form method ="POST">
    <?php if(!$edit): ?>
        <?php echo "click edit to add request"; ?>
        <?php else: ?>
            
        <h3>Add request: <input type="text" value="<?php echo $request; ?>" name="Request"/></h3> 
        <input style="background-color:#FED777; " type="submit" value="Update Order" name= "update" />
        <input  type="hidden" value="<?php echo $_POST["productID"]; ?>" name ="productID" />
    <?php endif;?>
</form>
<form method="POST" action="display_productitem.php">
           <input style="background-color:#FED777; " type="submit" value="Checkout and return to Menu" name="checkout"/>
</form>
</html>