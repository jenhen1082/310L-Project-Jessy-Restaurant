<?php 

    require_once("database.php");
    function getAllproduct()
    {
        $conn = getDbConn();
        $query = "select * from productitem";
        return mysqli_query($conn, $query);
    }

    function getproducts($productID)
    {
        $conn = getDbConn();
        $query = "select * from productitem where ProductID = $productID";
        return mysqli_query($conn, $query);
    }
?>