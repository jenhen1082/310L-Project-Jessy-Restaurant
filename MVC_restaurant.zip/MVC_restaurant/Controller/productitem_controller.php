<?php
require_once("../model/cartinfo.php");

function getProduct()
{
    $productRows = getAllproduct();
    $product = array();
    if($productRows)
    {
        $i = 0; // i don't know what this integer means
        while($row = mysqli_fetch_array($productRows))
        {
            $product[$i]["ProductID"] = ($row["ProductID"]);
            $product[$i]["ProductDescription"] = ($row["ProductDescription"]);
            $product[$i]["ProductCost"] = ($row["ProductCost"]);
            $product[$i]["QuantityInCart"] = ($row["QuantityInCart"]);
            $i++;
        }
    }
    return $product;
}



?>