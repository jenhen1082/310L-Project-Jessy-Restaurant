<?php
    require_once("../controller/productitem_controller.php");
    $productArray = getProduct();
?>

<html>
<head>
  

<title>Restaurant_MVC</title>
<style>
    body {
        background-color: #FFF5DC;
    }
    h1{
        text-align:center;
        text-decoration-line: underline overline;
    }

    table {
        border-spacing: 5px;
    }
    table, th,td {
        border:1px solid black;
        border-collapse: collapse;
    }
    th, td 
    {
        padding: 15px;
        text-align: center;
    }
    th{
        background-color: #FCBA12;
    }
    tr
    {
         background-color: #FED777;
    }
</style>
</head>

<body>
    <h1 style="background-color:cornsilk">Menu List:</h1>
    <table> 
        <tr>
            <th>Item</th>
            <th>Description</th>
            <th>Price</th>
            <th>Quantity</th>
        </tr>
    
        <?php foreach($productArray as $product):; ?>
           <tr>
           <td><?php echo $product["ProductID"]; ?></td>
           <td><?php echo $product["ProductDescription"]; ?></td>
           <td><?php echo $product["ProductCost"]; ?></td>
           <td><?php echo $product["QuantityInCart"]; ?></td>
           <td>
            <form method="POST">
                <input style="background-color:#FED777; " type= "number" value= "1" name="Qty" min="1" max="9"/>
                <input style="background-color:#FED777; " type="submit" value="Add to cart" name="add"/>
                <input type= "hidden" value="<?php echo $product["ProductID"]; ?>"name ="productID" />
            </form>
        </td>
            </tr>
         <?php endforeach; ?>
</table>
<form method="POST" action="display_shoppingcart.php">

            <input style="background-color:#FED777; " type="submit" value="Go to Cart" name="cart"/>
       </form>
</body>
</html>