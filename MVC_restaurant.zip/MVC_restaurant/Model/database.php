<?php 
    function getDbConn()
    {
        $hostname = "localhost";
        $username = "ecpi_user";
        $password = "Password1";
        $dbname = "restaurant";
        
        return mysqli_connect($hostname, $username, $password, $dbname);
    }
    $conn = getDbConn();
    $cartquery = "select * from productitem where QuantityInCart > 0 ";
    $cartresult = mysqli_query($conn, $cartquery);  
    $productID = -1;
    $request = "";
    $edit = false;

    if(isset($_POST["checkout"]))
        {
           $clearcartquery = "UPDATE `productitem` SET `QuantityInCart` = 0, `Request` = '' ";
            mysqli_query($conn, $clearcartquery);
        }
      
        if(isset($_POST["add"]))
        {
            $productID = $_POST["productID"];
            $quantityInCart = $_POST["Qty"];
                          
            $addQuery = "UPDATE `productitem` SET `QuantityInCart` = '$quantityInCart' WHERE `productitem`.`ProductID` = $productID";
                 mysqli_query($conn, $addQuery);
                 $productID = -1;
                 $productName = "";
                 $productDescription = "";
                 $productCost ="";
                 $quantityInCart = "";
                 $request = "";
    
        }
         else if (isset($_POST["update"]))
        {
            $productID = $_POST["productID"];
            $request = $_POST["Request"];
            $updateQuery = "UPDATE productitem set Request = '$request' WHERE `productitem`.`ProductID` = $productID";
            mysqli_query($conn, $updateQuery);
        }
         $query = "select * from productitem";
         $result = mysqli_query($conn, $query);
    
?>
<?php 
if(isset($_POST["productID"]))
   {
      //  this should tell me if we are inserting or updating
           $edit = isset($_POST["edit"]);
    }
    if (isset($_POST["delete"]))
    {
        $productID = $_POST["productID"];
        $deleteQuery = "UPDATE `productitem` SET `QuantityInCart` = 0, `Request` = '' WHERE `productitem`.`ProductID` = $productID";
        mysqli_query($conn, $deleteQuery);
        $productID = -1;
        $quantityInCart = "";
    }
    else if (isset($_POST["edit"]))
    {
        
         // get the record we need to edit
         $productID = $_POST["productID"];
         $selectQuery = "select * from productitem where ProductID = $productID";
         $result = mysqli_query($conn, $selectQuery);
         $userInfo = mysqli_fetch_assoc($result);
         //get the values to populate the textboxes
         $productID = $userInfo["ProductID"];
         //$request = $userInfo["Request"];
    }

?>

    <?php 
       // totals
       $subtotal = 0;
       $taxRate = 0.05;
       $shippingHandling = 0.10;

       mysqli_data_seek($result, 0);
       while($row = mysqli_fetch_array($result))
       {
            $subtotal += $row["ProductCost"] * $row["QuantityInCart"];
            
       }
       $shippingAndHandling = $subtotal * $shippingHandling;
       $tax = $subtotal * $taxRate;
       $productTotal = $subtotal + $tax + $shippingAndHandling;

       ?> 
   